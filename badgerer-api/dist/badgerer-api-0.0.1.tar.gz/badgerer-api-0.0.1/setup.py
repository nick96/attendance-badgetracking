# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['badgerer_api']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Cors==3.0.8',
 'Flask-Migrate==2.5.2',
 'Flask-SQLAlchemy==2.4.1',
 'Flask==1.1.1',
 'PyJWT==1.7.1',
 'argon2-cffi==19.1.0',
 'gunicorn==19.9.0',
 'marshmallow==3.2.1',
 'passlib==1.7.1',
 'psycopg2==2.8.3',
 'typed-ast==1.4.0']

setup_kwargs = {
    'name': 'badgerer-api',
    'version': '0.0.1',
    'description': 'Badgerer backend API',
    'long_description': None,
    'author': 'Nick Spain',
    'author_email': 'nicholas.spain96@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.7.4',
}


setup(**setup_kwargs)
